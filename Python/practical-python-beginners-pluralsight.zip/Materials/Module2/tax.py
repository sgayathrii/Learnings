amount = 200
tax = .07
total = amount + amount*tax
print(total)