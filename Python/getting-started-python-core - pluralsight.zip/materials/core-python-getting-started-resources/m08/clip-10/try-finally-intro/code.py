try:
    # try-block
finally:
    # executed no matter how the
    # try-block terminates
