def nth_root(radicand, n):
  return radicand ** (1/n)
