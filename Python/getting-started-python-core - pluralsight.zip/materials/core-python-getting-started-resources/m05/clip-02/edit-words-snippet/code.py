for word in story_words:
  print(word)
