class MyClassName:
    #     ⬆
    # By convention, class
    # names use CamelCase
    # . . .
