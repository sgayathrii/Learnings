"""Model for aircraft flights."""


class Flight: