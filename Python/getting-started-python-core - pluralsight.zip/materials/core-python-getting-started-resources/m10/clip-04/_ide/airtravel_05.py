"""Model for aircraft flights."""


class Flight:
    
    def number(self):
        return "SN060"
